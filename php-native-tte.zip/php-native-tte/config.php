<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'tte_native');
define('DB_USER', 'root');
define('DB_PASS', '');

// Base URL for QR and internal links
define('BASE_URL', 'http://localhost/php-native-tte');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
